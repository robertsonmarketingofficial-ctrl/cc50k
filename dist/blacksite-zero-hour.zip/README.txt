BLACKSITE: ZERO HOUR
Double-click BLACKSITE.html to play (Chrome, Edge or Firefox). No install or internet needed.
Controls: WASD move, mouse look, click shoot, right-click aim, Shift sprint, Q/E lean, C crouch,
F interact/takedown, R reload, 1/2 weapons, 3/4 gadgets, 5 drone, V cameras, Tab pack, M map, Esc pause.
Strong PC? Graphics extras (ambient occlusion + glow) are off by default for speed.
